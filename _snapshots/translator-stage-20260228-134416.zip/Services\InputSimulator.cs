using System.Runtime.InteropServices;
using System.Windows.Forms;
using TranslatorTray.Native;

namespace TranslatorTray.Services;

public sealed class InputSimulator
{
    public const long SyntheticExtraInfoTag = 0x0000000087654321L;
    public static bool IsOurSyntheticTag(IntPtr extraInfo) => extraInfo.ToInt64() == SyntheticExtraInfoTag;

    public void SendBackspaces(int count)
    {
        if (count <= 0) return;

        var inputs = new List<NativeMethods.INPUT>(count * 2);
        for (var i = 0; i < count; i++)
        {
            inputs.Add(KeyDown((ushort)NativeMethods.VK_BACK));
            inputs.Add(KeyUp((ushort)NativeMethods.VK_BACK));
        }

        Send(inputs);
    }

    public void SendText(string text)
    {
        if (string.IsNullOrEmpty(text)) return;

        var inputs = new List<NativeMethods.INPUT>(text.Length * 2);
        foreach (var c in text)
        {
            inputs.Add(new NativeMethods.INPUT
            {
                type = NativeMethods.INPUT_KEYBOARD,
                U = new NativeMethods.InputUnion
                {
                    ki = new NativeMethods.KEYBDINPUT
                    {
                        wVk = 0,
                        wScan = c,
                        dwFlags = NativeMethods.KEYEVENTF_UNICODE,
                        dwExtraInfo = new IntPtr(SyntheticExtraInfoTag)
                    }
                }
            });
            inputs.Add(new NativeMethods.INPUT
            {
                type = NativeMethods.INPUT_KEYBOARD,
                U = new NativeMethods.InputUnion
                {
                    ki = new NativeMethods.KEYBDINPUT
                    {
                        wVk = 0,
                        wScan = c,
                        dwFlags = NativeMethods.KEYEVENTF_UNICODE | NativeMethods.KEYEVENTF_KEYUP,
                        dwExtraInfo = new IntPtr(SyntheticExtraInfoTag)
                    }
                }
            });
        }

        Send(inputs);
    }

    public void SendCtrlCombo(Keys key)
    {
        SendChord((ushort)NativeMethods.VK_LCONTROL, (ushort)key);
    }

    public void SendCtrlInsert()
    {
        SendChord((ushort)NativeMethods.VK_LCONTROL, 0x2D); // VK_INSERT
    }

    public void SendShiftInsert()
    {
        SendChord((ushort)NativeMethods.VK_LSHIFT, 0x2D); // VK_INSERT
    }

    public void ReleaseModifiers()
    {
        var inputs = new List<NativeMethods.INPUT>(12)
        {
            KeyUp((ushort)NativeMethods.VK_LCONTROL),
            KeyUp((ushort)NativeMethods.VK_RCONTROL),
            KeyUp((ushort)NativeMethods.VK_CONTROL),
            KeyUp((ushort)NativeMethods.VK_LSHIFT),
            KeyUp((ushort)NativeMethods.VK_RSHIFT),
            KeyUp((ushort)NativeMethods.VK_SHIFT),
            KeyUp((ushort)NativeMethods.VK_LMENU),
            KeyUp((ushort)NativeMethods.VK_RMENU),
            KeyUp((ushort)NativeMethods.VK_MENU),
        };
        Send(inputs);
    }

    private static NativeMethods.INPUT KeyDown(ushort vk) =>
        new()
        {
            type = NativeMethods.INPUT_KEYBOARD,
            U = new NativeMethods.InputUnion
            {
                ki = new NativeMethods.KEYBDINPUT
                {
                    wVk = vk,
                    wScan = (ushort)NativeMethods.MapVirtualKey(vk, NativeMethods.MAPVK_VK_TO_VSC),
                    dwExtraInfo = new IntPtr(SyntheticExtraInfoTag)
                }
            }
        };

    private static NativeMethods.INPUT KeyUp(ushort vk) =>
        new()
        {
            type = NativeMethods.INPUT_KEYBOARD,
            U = new NativeMethods.InputUnion
            {
                ki = new NativeMethods.KEYBDINPUT
                {
                    wVk = vk,
                    wScan = (ushort)NativeMethods.MapVirtualKey(vk, NativeMethods.MAPVK_VK_TO_VSC),
                    dwFlags = NativeMethods.KEYEVENTF_KEYUP,
                    dwExtraInfo = new IntPtr(SyntheticExtraInfoTag)
                }
            }
        };

    private static void Send(List<NativeMethods.INPUT> inputs)
    {
        if (inputs.Count == 0) return;
        NativeMethods.SendInput((uint)inputs.Count, inputs.ToArray(), Marshal.SizeOf<NativeMethods.INPUT>());
    }

    private static void SendOne(NativeMethods.INPUT input)
    {
        NativeMethods.SendInput(1, [input], Marshal.SizeOf<NativeMethods.INPUT>());
    }

    private static void SendChord(ushort modifierVk, ushort keyVk)
    {
        // Some apps behave better with paced key events than a single 4-input batch.
        SendOne(KeyDown(modifierVk));
        Thread.Sleep(4);
        SendOne(KeyDown(keyVk));
        Thread.Sleep(4);
        SendOne(KeyUp(keyVk));
        Thread.Sleep(4);
        SendOne(KeyUp(modifierVk));
    }
}
