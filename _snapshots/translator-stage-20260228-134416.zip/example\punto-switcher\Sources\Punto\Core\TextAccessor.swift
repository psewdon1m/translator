import AppKit
import ApplicationServices
import Carbon.HIToolbox

/// Handles getting and setting selected text using Accessibility API
/// Falls back to clipboard-based approach for apps that don't support Accessibility
final class TextAccessor {

    /// Tracks if the last getSelectedText used clipboard fallback
    /// If true, setSelectedText should also use clipboard (Cmd+V) since AX won't work
    private var lastGetUsedClipboard = false

    // MARK: - Terminal Detection
    
    private static let terminalBundleIDs: Set<String> = [
        "com.apple.Terminal",
        "com.googlecode.iterm2",
        "com.mitchellh.ghostty",
        "io.alacritty",
        "net.kovidgoyal.kitty"
    ]
    
    func isTerminalApp() -> Bool {
        guard let frontApp = NSWorkspace.shared.frontmostApplication,
              let bundleID = frontApp.bundleIdentifier else { return false }
        return Self.terminalBundleIDs.contains(bundleID)
    }

    // MARK: - Security Detection

    /// Checks if Secure Keyboard Input is enabled (e.g., in Terminal password prompts)
    /// When enabled, CGEvent simulation is blocked for security
    func isSecureInputEnabled() -> Bool {
        return IsSecureEventInputEnabled()
    }

    /// Checks if focused element is a secure/password text field
    /// Used to skip conversion in browser password fields
    func isPasswordField() -> Bool {
        guard let element = getFocusedElement() else {
            return false
        }

        // Check subrole for AXSecureTextField
        var subrole: AnyObject?
        if AXUIElementCopyAttributeValue(element, kAXSubroleAttribute as CFString, &subrole) == .success,
           let sr = subrole as? String,
           sr == "AXSecureTextField" {
            return true
        }

        return false
    }

    // MARK: - Get Selected Text

    /// Result of trying to get selected text via Accessibility API
    private enum AXGetResult {
        case text(String)       // Got non-empty selected text
        case empty              // AX worked, but nothing is selected
        case noFocus            // Couldn't get focused element (skip clipboard, use WordTracker)
        case failed             // AX API failed on element (should try clipboard fallback)
    }

    /// Attempts to get the currently selected text using Accessibility API
    /// Falls back to Cmd+C clipboard method for browsers/apps that don't expose selectedText
    func getSelectedText() -> String? {
        // 1. Try Accessibility API (direct access)
        switch getSelectedTextViaAccessibility() {
        case .text(let text):
            lastGetUsedClipboard = false
            return text
        case .empty:
            // AX worked, nothing selected - no need for clipboard fallback
            lastGetUsedClipboard = false
            return nil
        case .noFocus:
            // Couldn't get focused element - still try clipboard fallback
            // Some apps (like VS Code extension host) don't expose AX elements
            // but still support Cmd+C for selected text
            lastGetUsedClipboard = true
            PuntoLog.info("getSelectedText: noFocus, trying clipboard fallback")
            return getSelectedTextViaClipboard()
        case .failed:
            // AX failed on specific element - try clipboard fallback for browsers
            lastGetUsedClipboard = true
            return getSelectedTextViaClipboard()
        }
    }

    private func getSelectedTextViaAccessibility() -> AXGetResult {
        guard let focusedElement = getFocusedElement() else {
            PuntoLog.info("getSelectedTextViaAccessibility: no focused element")
            return .noFocus
        }

        // Direct attempt on focused element
        switch tryGetSelectedText(focusedElement) {
        case .text(let text):
            PuntoLog.info("getSelectedTextViaAccessibility: direct succeeded")
            return .text(text)
        case .empty:
            PuntoLog.info("getSelectedTextViaAccessibility: direct returned empty (nothing selected)")
            return .empty
        case .noFocus, .failed:
            break  // Continue to other methods
        }

        // For Safari/Electron: try via app's focusedUIElement
        if let appFocusedElement = getAppFocusedElement() {
            switch tryGetSelectedText(appFocusedElement) {
            case .text(let text):
                PuntoLog.info("getSelectedTextViaAccessibility: appFocusedElement succeeded")
                return .text(text)
            case .empty:
                return .empty
            case .noFocus, .failed:
                break
            }
        }

        // Recursive search in children (maxDepth=5)
        if let text = searchForSelectedText(focusedElement, depth: 0) {
            PuntoLog.info("getSelectedTextViaAccessibility: recursive search found text")
            return .text(text)
        }

        // All methods failed - might be a browser that needs clipboard fallback
        PuntoLog.info("getSelectedTextViaAccessibility: all methods failed")
        return .failed
    }

    /// Attempts to get selectedText from an element
    private func tryGetSelectedText(_ element: AXUIElement) -> AXGetResult {
        var selectedText: AnyObject?
        let result = AXUIElementCopyAttributeValue(
            element,
            kAXSelectedTextAttribute as CFString,
            &selectedText
        )

        // AX API failed - element doesn't support selectedText
        if result != .success {
            return .failed
        }

        // AX API succeeded - check if there's actual text
        if let text = selectedText as? String, !text.isEmpty {
            PuntoLog.info("tryGetSelectedText: got '\(text.prefix(30))'")
            return .text(text)
        }

        // AX succeeded but returned empty string = nothing selected
        return .empty
    }

    /// Gets focusedUIElement directly from application (bypass for Electron/Safari)
    private func getAppFocusedElement() -> AXUIElement? {
        let systemWide = AXUIElementCreateSystemWide()

        var focusedApp: AnyObject?
        let appResult = AXUIElementCopyAttributeValue(
            systemWide,
            kAXFocusedApplicationAttribute as CFString,
            &focusedApp
        )
        guard appResult == .success else {
            PuntoLog.info("getAppFocusedElement: failed to get app, error=\(appResult.rawValue)")
            return nil
        }

        let appElement = focusedApp as! AXUIElement

        var focusedElement: AnyObject?
        let elemResult = AXUIElementCopyAttributeValue(
            appElement,
            kAXFocusedUIElementAttribute as CFString,
            &focusedElement
        )
        guard elemResult == .success else {
            PuntoLog.info("getAppFocusedElement: failed to get focusedUIElement, error=\(elemResult.rawValue)")
            return nil
        }

        PuntoLog.info("getAppFocusedElement: got focusedUIElement")
        return (focusedElement as! AXUIElement)
    }

    /// Recursive search for selectedText in child elements
    private func searchForSelectedText(_ element: AXUIElement, depth: Int) -> String? {
        guard depth < 5 else {
            return nil
        }

        var children: AnyObject?
        let childResult = AXUIElementCopyAttributeValue(
            element,
            kAXChildrenAttribute as CFString,
            &children
        )
        guard childResult == .success, let childArray = children as? [AXUIElement] else {
            return nil
        }

        for child in childArray {
            // First check the element itself
            if case .text(let text) = tryGetSelectedText(child) {
                PuntoLog.info("searchForSelectedText: found text at depth \(depth)")
                return text
            }
            // Then recursively search in its children
            if let text = searchForSelectedText(child, depth: depth + 1) {
                return text
            }
        }
        return nil
    }

    // MARK: - Clipboard Fallback

    private func getSelectedTextViaClipboard() -> String? {
        PuntoLog.info("getSelectedTextViaClipboard: using Cmd+C fallback")

        let pasteboard = NSPasteboard.general
        let previousContent = pasteboard.string(forType: .string)
        let initialChangeCount = pasteboard.changeCount

        pasteboard.clearContents()

        // Send Cmd+C via CGEvent (fastest method)
        let source = CGEventSource(stateID: .combinedSessionState)
        if let keyDown = CGEvent(keyboardEventSource: source, virtualKey: 8, keyDown: true) {
            keyDown.flags = .maskCommand
            keyDown.post(tap: .cgAnnotatedSessionEventTap)
        }
        Thread.sleep(forTimeInterval: 0.01)
        if let keyUp = CGEvent(keyboardEventSource: source, virtualKey: 8, keyDown: false) {
            keyUp.flags = .maskCommand
            keyUp.post(tap: .cgAnnotatedSessionEventTap)
        }

        // Poll clipboard with short intervals instead of one long wait
        // This makes fast apps respond quickly while still supporting slow ones
        for i in 1...10 {
            Thread.sleep(forTimeInterval: 0.02)  // 20ms per iteration, max 200ms total
            if pasteboard.changeCount != initialChangeCount {
                break
            }
            // After 60ms, try HID fallback
            if i == 3 {
                let sourceHID = CGEventSource(stateID: .hidSystemState)
                if let keyDown = CGEvent(keyboardEventSource: sourceHID, virtualKey: 8, keyDown: true) {
                    keyDown.flags = .maskCommand
                    keyDown.post(tap: .cghidEventTap)
                }
                Thread.sleep(forTimeInterval: 0.01)
                if let keyUp = CGEvent(keyboardEventSource: sourceHID, virtualKey: 8, keyDown: false) {
                    keyUp.flags = .maskCommand
                    keyUp.post(tap: .cghidEventTap)
                }
            }
        }

        let selected = pasteboard.string(forType: .string)

        guard let text = selected, !text.isEmpty else {
            PuntoLog.info("getSelectedTextViaClipboard: no text in clipboard")
            return nil
        }

        // If clipboard content is same as before, nothing was selected
        if text == previousContent {
            PuntoLog.info("getSelectedTextViaClipboard: clipboard unchanged (nothing selected)")
            return nil
        }

        // Trim trailing whitespace - some apps (like Cursor) add newlines when copying
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            PuntoLog.info("getSelectedTextViaClipboard: got only whitespace, treating as empty")
            return nil
        }

        PuntoLog.info("getSelectedTextViaClipboard: got '\(trimmed.prefix(30))' (trimmed from \(text.count) to \(trimmed.count) chars)")
        return trimmed
    }

    // MARK: - Set Selected Text

    /// Replaces the currently selected text with new text
    /// - Parameters:
    ///   - text: The text to insert
    ///   - keepSelection: If true, the inserted text will be selected after insertion (for undo support)
    func setSelectedText(_ text: String, keepSelection: Bool = false) {
        PuntoLog.info("setSelectedText called with \(text.count) chars, keepSelection=\(keepSelection), lastGetUsedClipboard=\(lastGetUsedClipboard)")

        // If getSelectedText used clipboard, we must use clipboard for set too
        // because AX API returns "success" but doesn't actually work for web content
        if lastGetUsedClipboard {
            PuntoLog.info("setSelectedText: using clipboard (matched get method)")
            setSelectedTextViaClipboard(text, selectAfterPaste: keepSelection)
            return
        }

        // Try Accessibility API first
        if setSelectedTextViaAccessibility(text, keepSelection: keepSelection) {
            PuntoLog.info("setSelectedText: Accessibility API succeeded")
            return
        }

        PuntoLog.info("setSelectedText: Accessibility API failed, using clipboard")
        // Fall back to clipboard method
        setSelectedTextViaClipboard(text, selectAfterPaste: keepSelection)
    }

    private func setSelectedTextViaAccessibility(_ text: String, keepSelection: Bool = false) -> Bool {
        guard let focusedElement = getFocusedElement() else {
            PuntoLog.info("setSelectedTextViaAccessibility: no focused element")
            return false
        }

        // Get current selected text to verify change later
        var currentSelectedText: AnyObject?
        AXUIElementCopyAttributeValue(focusedElement, kAXSelectedTextAttribute as CFString, &currentSelectedText)
        let originalText = currentSelectedText as? String

        // Get current selection range before replacing
        var selectionRange: AnyObject?
        var startIndex: Int = 0
        if keepSelection {
            if AXUIElementCopyAttributeValue(focusedElement, kAXSelectedTextRangeAttribute as CFString, &selectionRange) == .success,
               let range = selectionRange {
                var cfRange = CFRange(location: 0, length: 0)
                // selectionRange is an AXValue containing CFRange
                AXValueGetValue(range as! AXValue, .cfRange, &cfRange)
                startIndex = cfRange.location
            }
        }

        let result = AXUIElementSetAttributeValue(
            focusedElement,
            kAXSelectedTextAttribute as CFString,
            text as CFTypeRef
        )

        if result != .success {
            PuntoLog.info("setSelectedTextViaAccessibility: AXUIElementSetAttributeValue failed with \(result.rawValue)")
            return false
        }

        // Verify the text actually changed (Safari returns success but doesn't change text)
        Thread.sleep(forTimeInterval: 0.05)
        var newSelectedText: AnyObject?
        AXUIElementCopyAttributeValue(focusedElement, kAXSelectedTextAttribute as CFString, &newSelectedText)
        let actualText = newSelectedText as? String

        // If text didn't change or still equals original, AX set failed silently
        if actualText == originalText && originalText != text {
            PuntoLog.info("setSelectedTextViaAccessibility: AX returned success but text unchanged (Safari bug), original='\(originalText ?? "nil")', expected='\(text)'")
            return false
        }

        PuntoLog.info("setSelectedTextViaAccessibility: verified text changed to '\(actualText?.prefix(20) ?? "nil")'")

        // If keepSelection is true, select the inserted text
        if keepSelection {
            var newRange = CFRange(location: startIndex, length: text.utf16.count)
            if let rangeValue = AXValueCreate(.cfRange, &newRange) {
                let selectResult = AXUIElementSetAttributeValue(
                    focusedElement,
                    kAXSelectedTextRangeAttribute as CFString,
                    rangeValue
                )
                if selectResult == .success {
                    PuntoLog.info("setSelectedTextViaAccessibility: re-selected \(text.count) chars")
                } else {
                    PuntoLog.info("setSelectedTextViaAccessibility: failed to re-select, error=\(selectResult.rawValue)")
                }
            }
        }

        return true
    }

    private func setSelectedTextViaClipboard(_ text: String, selectAfterPaste: Bool = false) {
        let pasteboard = NSPasteboard.general

        // Save current clipboard to restore later
        let savedClipboard = pasteboard.string(forType: .string)

        // Set new text to clipboard
        pasteboard.clearContents()
        pasteboard.setString(text, forType: .string)

        PuntoLog.info("setSelectedTextViaClipboard: pasting \(text.count) chars")

        // Simulate Cmd+V
        simulatePaste()
        Thread.sleep(forTimeInterval: 0.03)

        PuntoLog.info("setSelectedTextViaClipboard: paste completed")

        // Select the pasted text using Shift+Cmd+Left (select to beginning of line/word)
        // Much faster than character-by-character selection
        if selectAfterPaste {
            Thread.sleep(forTimeInterval: 0.02)
            selectBackwardsFast(characterCount: text.count)
            PuntoLog.info("setSelectedTextViaClipboard: selected backwards")
        }

        // Restore original clipboard asynchronously
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            if let old = savedClipboard {
                pasteboard.clearContents()
                pasteboard.setString(old, forType: .string)
            }
        }
    }

    /// Fast backward selection using Shift+Arrow with batching
    private func selectBackwardsFast(characterCount: Int) {
        let source = CGEventSource(stateID: .hidSystemState)

        // Always use character-by-character selection for precision
        // Word-based selection (Opt+Shift+Left) can overshoot and select extra content
        for _ in 0..<characterCount {
            if let keyDown = CGEvent(keyboardEventSource: source, virtualKey: 123, keyDown: true) {
                keyDown.flags = .maskShift
                keyDown.post(tap: .cghidEventTap)
            }
            if let keyUp = CGEvent(keyboardEventSource: source, virtualKey: 123, keyDown: false) {
                keyUp.flags = .maskShift
                keyUp.post(tap: .cghidEventTap)
            }
        }
        Thread.sleep(forTimeInterval: 0.02)
    }

    /// Simulates Cmd+V keystroke for paste operation
    private func simulatePaste() {
        // Use .cghidEventTap for better Safari compatibility
        let source = CGEventSource(stateID: .hidSystemState)

        // Create key down event for V with Command modifier
        if let keyDown = CGEvent(keyboardEventSource: source, virtualKey: 9, keyDown: true) {
            keyDown.flags = .maskCommand
            keyDown.post(tap: .cghidEventTap)
        }

        Thread.sleep(forTimeInterval: 0.02)

        // Create key up event for V with Command modifier
        if let keyUp = CGEvent(keyboardEventSource: source, virtualKey: 9, keyDown: false) {
            keyUp.flags = .maskCommand
            keyUp.post(tap: .cghidEventTap)
        }

        PuntoLog.info("simulatePaste: sent Cmd+V via CGEvent (HID)")
    }

    // MARK: - Replace Last Word

    /// Deletes the last word and pastes the replacement via clipboard
    func replaceLastWord(wordLength: Int, with replacement: String) {
        let startTime = Date()

        // Log active app state before sending events
        if let frontApp = NSWorkspace.shared.frontmostApplication {
            let isActive = frontApp.isActive
            let isHidden = frontApp.isHidden
            PuntoLog.info("replaceLastWord: target app='\(frontApp.localizedName ?? "?")' isActive=\(isActive) isHidden=\(isHidden) pid=\(frontApp.processIdentifier)")
        }

        // Check keyboard focus via AX before sending events
        let axFocusCheck = checkKeyboardFocus()
        PuntoLog.info("replaceLastWord: AX focus check: \(axFocusCheck)")

        PuntoLog.info("replaceLastWord: deleting \(wordLength) chars, replacing with '\(replacement)'")

        // Check current modifier state BEFORE delay
        let modifiersBefore = CGEventSource.flagsState(.hidSystemState)
        let modDescBefore = describeModifiers(modifiersBefore)
        PuntoLog.info("replaceLastWord: modifiers BEFORE delay: \(modDescBefore)")

        // Small delay before starting to let the app stabilize after modifier release
        Thread.sleep(forTimeInterval: 0.05)

        // Check modifier state AFTER delay
        let modifiersAfter = CGEventSource.flagsState(.hidSystemState)
        let modDescAfter = describeModifiers(modifiersAfter)
        PuntoLog.info("replaceLastWord: modifiers AFTER 50ms delay: \(modDescAfter)")

        let source = CGEventSource(stateID: .hidSystemState)

        // Check if event source was created
        if source == nil {
            PuntoLog.error("replaceLastWord: FAILED to create CGEventSource!")
        }

        // Delete characters one by one using Backspace (keyCode 51)
        // Using .cghidEventTap which works for most apps
        PuntoLog.info("replaceLastWord: sending \(wordLength) backspaces via cghidEventTap (after 50ms delay)")
        var backspacesSent = 0
        // For terminals: use Ctrl+U to clear line instead of backspaces
        if isTerminalApp() {
            PuntoLog.info("replaceLastWord: terminal detected, using Ctrl+U")
            if let keyDown = CGEvent(keyboardEventSource: source, virtualKey: 32, keyDown: true),
               let keyUp = CGEvent(keyboardEventSource: source, virtualKey: 32, keyDown: false) {
                keyDown.flags = .maskControl
                keyUp.flags = .maskControl
                keyDown.post(tap: .cghidEventTap)
                keyUp.post(tap: .cghidEventTap)
                backspacesSent = wordLength
            }
            Thread.sleep(forTimeInterval: 0.05)
        } else {
            for i in 0..<wordLength {
                let keyDown = CGEvent(keyboardEventSource: source, virtualKey: 51, keyDown: true)
                let keyUp = CGEvent(keyboardEventSource: source, virtualKey: 51, keyDown: false)

                if keyDown == nil || keyUp == nil {
                    PuntoLog.error("replaceLastWord: FAILED to create backspace event #\(i+1)")
                    continue
                }

                keyDown!.post(tap: .cghidEventTap)
                keyUp!.post(tap: .cghidEventTap)
                Thread.sleep(forTimeInterval: 0.02)
                backspacesSent += 1
            }
        }
        let backspaceTime = Date().timeIntervalSince(startTime) * 1000
        PuntoLog.info("replaceLastWord: \(backspacesSent)/\(wordLength) backspaces sent in \(String(format: "%.1f", backspaceTime))ms, waiting 20ms")
        Thread.sleep(forTimeInterval: 0.02)

        // Paste replacement via clipboard (much faster than typing)
        let pasteboard = NSPasteboard.general
        let savedClipboard = pasteboard.string(forType: .string)

        pasteboard.clearContents()
        pasteboard.setString(replacement, forType: .string)

        // Simulate Cmd+V
        let pasteStartTime = Date()
        simulatePaste()
        Thread.sleep(forTimeInterval: 0.03)
        let pasteTime = Date().timeIntervalSince(pasteStartTime) * 1000
        PuntoLog.info("replaceLastWord: paste took \(String(format: "%.1f", pasteTime))ms")

        // Verify paste worked by checking clipboard wasn't cleared by app
        let clipboardAfterPaste = pasteboard.string(forType: .string)
        if clipboardAfterPaste == replacement {
            PuntoLog.info("replaceLastWord: clipboard still contains replacement (paste likely succeeded)")
        } else {
            PuntoLog.info("replaceLastWord: clipboard changed to '\(clipboardAfterPaste?.prefix(20) ?? "nil")' (app may have modified it)")
        }

        // Note: Active verification via select+copy is destructive - removed
        // Instead rely on AX focus check and clipboard state for diagnostics

        // Restore clipboard asynchronously
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            if let old = savedClipboard {
                pasteboard.clearContents()
                pasteboard.setString(old, forType: .string)
                PuntoLog.debug("replaceLastWord: clipboard restored to original")
            }
        }

        let totalTime = Date().timeIntervalSince(startTime) * 1000
        PuntoLog.info("replaceLastWord: completed in \(String(format: "%.1f", totalTime))ms (sent \(backspacesSent) backspaces + Cmd+V with '\(replacement)')")
    }

    // MARK: - Helpers

    private func getFocusedElement() -> AXUIElement? {
        let systemWide = AXUIElementCreateSystemWide()

        // Try to get focused application with retry
        // Sometimes AX API returns -25212 temporarily
        var focusedApp: AnyObject?
        var appResult: AXError = .failure

        for attempt in 1...3 {
            appResult = AXUIElementCopyAttributeValue(
                systemWide,
                kAXFocusedApplicationAttribute as CFString,
                &focusedApp
            )
            if appResult == .success {
                break
            }
            if attempt < 3 {
                Thread.sleep(forTimeInterval: 0.05)
            }
        }

        guard appResult == .success, let app = focusedApp else {
            // Log which app is frontmost via NSWorkspace (works even when AX fails)
            if let frontApp = NSWorkspace.shared.frontmostApplication {
                PuntoLog.info("getFocusedElement: AX failed (error=\(appResult.rawValue)) for app '\(frontApp.localizedName ?? "?")' bundle=\(frontApp.bundleIdentifier ?? "?")")
            } else {
                PuntoLog.info("getFocusedElement: AX failed (error=\(appResult.rawValue)), no frontmost app")
            }
            return nil
        }

        let appElement = app as! AXUIElement

        // Log which app is focused
        var appTitle: AnyObject?
        if AXUIElementCopyAttributeValue(appElement, kAXTitleAttribute as CFString, &appTitle) == .success {
            PuntoLog.info("getFocusedElement: focused app is '\(appTitle as? String ?? "unknown")'")
        }

        var focusedElement: AnyObject?
        let elemResult = AXUIElementCopyAttributeValue(
            appElement,
            kAXFocusedUIElementAttribute as CFString,
            &focusedElement
        )
        guard elemResult == .success else {
            PuntoLog.info("getFocusedElement: failed to get focused element, error=\(elemResult.rawValue)")
            return nil
        }

        // Log element role
        var role: AnyObject?
        if AXUIElementCopyAttributeValue(focusedElement as! AXUIElement, kAXRoleAttribute as CFString, &role) == .success {
            PuntoLog.info("getFocusedElement: focused element role='\(role as? String ?? "unknown")'")
        }

        return (focusedElement as! AXUIElement)
    }

    private func simulateKeyPress(keyCode: CGKeyCode, flags: CGEventFlags) {
        // Use privateState for better isolation
        let source = CGEventSource(stateID: .privateState)

        // Key down
        if let keyDown = CGEvent(keyboardEventSource: source, virtualKey: keyCode, keyDown: true) {
            keyDown.flags = flags
            keyDown.post(tap: .cghidEventTap)
        }

        // Small delay between key down and key up
        Thread.sleep(forTimeInterval: 0.01)

        // Key up
        if let keyUp = CGEvent(keyboardEventSource: source, virtualKey: keyCode, keyDown: false) {
            keyUp.flags = flags
            keyUp.post(tap: .cghidEventTap)
        }
    }

    // MARK: - Debugging Helpers

    /// Describes current modifier key state
    private func describeModifiers(_ flags: CGEventFlags) -> String {
        var parts: [String] = []
        if flags.contains(.maskCommand) { parts.append("⌘") }
        if flags.contains(.maskAlternate) { parts.append("⌥") }
        if flags.contains(.maskShift) { parts.append("⇧") }
        if flags.contains(.maskControl) { parts.append("⌃") }
        return parts.isEmpty ? "none" : parts.joined()
    }

    /// Checks keyboard focus state via AX API
    /// Returns a string describing the current focus state
    private func checkKeyboardFocus() -> String {
        let systemWide = AXUIElementCreateSystemWide()

        // Get focused app
        var focusedApp: AnyObject?
        let appResult = AXUIElementCopyAttributeValue(
            systemWide,
            kAXFocusedApplicationAttribute as CFString,
            &focusedApp
        )

        guard appResult == .success, let app = focusedApp else {
            return "NO_FOCUSED_APP (error=\(appResult.rawValue))"
        }

        let appElement = app as! AXUIElement

        // Get app title
        var appTitle: AnyObject?
        AXUIElementCopyAttributeValue(appElement, kAXTitleAttribute as CFString, &appTitle)
        let appName = appTitle as? String ?? "?"

        // Get focused UI element
        var focusedElement: AnyObject?
        let elemResult = AXUIElementCopyAttributeValue(
            appElement,
            kAXFocusedUIElementAttribute as CFString,
            &focusedElement
        )

        guard elemResult == .success, let element = focusedElement else {
            return "app='\(appName)' NO_FOCUSED_ELEMENT (error=\(elemResult.rawValue))"
        }

        let axElement = element as! AXUIElement

        // Get element role
        var role: AnyObject?
        AXUIElementCopyAttributeValue(axElement, kAXRoleAttribute as CFString, &role)
        let roleName = role as? String ?? "?"

        // Check if element is enabled
        var enabled: AnyObject?
        AXUIElementCopyAttributeValue(axElement, kAXEnabledAttribute as CFString, &enabled)
        let isEnabled = enabled as? Bool ?? true

        // Check if element has keyboard focus
        var focused: AnyObject?
        AXUIElementCopyAttributeValue(axElement, kAXFocusedAttribute as CFString, &focused)
        let hasFocus = focused as? Bool ?? false

        return "app='\(appName)' role='\(roleName)' enabled=\(isEnabled) focused=\(hasFocus)"
    }

    /// Verifies that replacement was actually applied by selecting and copying the text
    /// Returns description of what was found
    private func verifyReplacementApplied(expectedText: String, charCount: Int) -> String {
        let pasteboard = NSPasteboard.general
        let beforeVerify = pasteboard.changeCount

        // Clear clipboard
        pasteboard.clearContents()

        // Select backwards (Shift+Left Arrow) to select the just-pasted text
        let source = CGEventSource(stateID: .hidSystemState)
        for _ in 0..<charCount {
            if let keyDown = CGEvent(keyboardEventSource: source, virtualKey: 123, keyDown: true) {
                keyDown.flags = .maskShift
                keyDown.post(tap: .cghidEventTap)
            }
            if let keyUp = CGEvent(keyboardEventSource: source, virtualKey: 123, keyDown: false) {
                keyUp.flags = .maskShift
                keyUp.post(tap: .cghidEventTap)
            }
        }
        Thread.sleep(forTimeInterval: 0.03)

        // Copy selected text (Cmd+C)
        if let keyDown = CGEvent(keyboardEventSource: source, virtualKey: 8, keyDown: true) {
            keyDown.flags = .maskCommand
            keyDown.post(tap: .cghidEventTap)
        }
        Thread.sleep(forTimeInterval: 0.01)
        if let keyUp = CGEvent(keyboardEventSource: source, virtualKey: 8, keyDown: false) {
            keyUp.flags = .maskCommand
            keyUp.post(tap: .cghidEventTap)
        }
        Thread.sleep(forTimeInterval: 0.05)

        // Check what we got
        let afterVerify = pasteboard.changeCount
        if afterVerify == beforeVerify {
            // Clipboard didn't change - selection/copy failed
            // Deselect by pressing Right arrow
            if let keyDown = CGEvent(keyboardEventSource: source, virtualKey: 124, keyDown: true) {
                keyDown.post(tap: .cghidEventTap)
            }
            if let keyUp = CGEvent(keyboardEventSource: source, virtualKey: 124, keyDown: false) {
                keyUp.post(tap: .cghidEventTap)
            }
            return "CLIPBOARD_UNCHANGED (copy failed?)"
        }

        let copiedText = pasteboard.string(forType: .string) ?? ""

        // Deselect by pressing Right arrow to move cursor to end
        if let keyDown = CGEvent(keyboardEventSource: source, virtualKey: 124, keyDown: true) {
            keyDown.post(tap: .cghidEventTap)
        }
        if let keyUp = CGEvent(keyboardEventSource: source, virtualKey: 124, keyDown: false) {
            keyUp.post(tap: .cghidEventTap)
        }

        if copiedText == expectedText {
            return "OK (verified '\(expectedText)')"
        } else if copiedText.isEmpty {
            return "EMPTY (expected '\(expectedText)')"
        } else {
            return "MISMATCH got='\(copiedText)' expected='\(expectedText)'"
        }
    }
}
